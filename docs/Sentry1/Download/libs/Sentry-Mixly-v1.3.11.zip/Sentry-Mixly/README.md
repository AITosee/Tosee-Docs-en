Sentry-Mixly-Arduino
=======================

Open source Mixly library for Sentry



![sentry_set](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/sentry_set.png)

![system_set](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/system_set.png)



![sentry_set_up](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/sentry_set_up.png)





![sentry_cood](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/sentry_cood.png)





![sentry_led](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/sentry_led.png)







![version_status](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_status.png)





![version_res_count](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_res_count.png)





![version_res_obj](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_res_obj.png)



![version_res_obj1](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_res_obj1.png)







![version_color_obj](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_color_obj.png)







![version_qr_obj](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_qr_obj.png)





![version_qr_str](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_qr_str.png)





![version_blod_de](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_blod_de.png)





![version_card_de](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_card_de.png)



![version_class20_de](https://github.com/Uniquemf/Sentry-Mixly-Arduino/blob/main/media/image/version_class20_de.png)






## What about other library for Sentry?

* Arduino	[https://github.com/AITosee/Sentry-Arduino](https://github.com/AITosee/Sentry-Arduino)
* Micro:Bit	[https://github.com/mu-opensource/pxt-Sentry](https://github.com/mu-opensource/pxt-Sentry)

## For more information

Check out the official site [https://tosee.readthedocs.io/zh/latest/index.html](https://tosee.readthedocs.io/zh/latest/index.html) for links to documentation, issues, and news
