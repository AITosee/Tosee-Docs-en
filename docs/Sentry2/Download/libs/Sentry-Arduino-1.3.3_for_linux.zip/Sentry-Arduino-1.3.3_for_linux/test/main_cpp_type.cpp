/**
 * @file main_cpp_type.cpp
 * @author donion.yang
 * @brief Linux平台下Sentry库的示例函数，目前只支持uart方式
 *        
 *        1）
 *        默认提供linux平台的使用方式，使用方法：
 *        确认 CMakeList.txt 中，编译的为 main_cpp_type.cpp 函数
 *        add_executable(linux_test main_cpp_type.cpp  ${SRC_LIST1} ${SRC_LIST2} ${SRC_LIST3}
 *        
 *        cd test
 *        mkdir build
 *        cd build
 *        cmake ..
 *        make
 *        ./linux_test
 * 
 *        2）
 *        其他平台需要用户修改uart的接口函数
 *        在 “src/hardware/hw_conf.h” 中，关闭 #define _PLATFORM_LINUX_ 的注释，打开 #define _PLATFORM_USER_ 的注释
 *        在 “src/hardware/hw_uart_user.h” 中，填写相关的uart接口函数
 *        使用用户的工具链去编译和运行函数
 *        
 * @version 1.2
 * @date 2023-01-15
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#include <Sentry.h>
#include "stdio.h"
#include "stdint.h"
#include <unistd.h>

typedef Sentry2 Sentry;

#define SENTRY_UART
#define VISION_MASK Sentry::kVisionColor
Sentry sentry;

LinuxUart linux_uart;

const char* blob_classes[] = {
  "UNKNOWN", "BLACK", "WHITE", "RED", "GREEN", "BLUE", "YELLOW"
};

void setup() {
  sentry_err_t err = SENTRY_OK;
  printf("Waiting for sentry initialize...\n");
  
  linux_uart.begin("/dev/ttyACM0", 921600);

  while (SENTRY_OK != sentry.begin(&linux_uart)) { 
    printf("sentry.begin...\n");
    usleep(200);
  }
  printf("Sentry begin Success.\n");

  err = sentry.VisionBegin(VISION_MASK);
  printf("sentry.VisionBegin(kVisionColor): %s[0x%x]\n", err ? "Error" : "Success", err);
}

void loop() {
  int obj_num = sentry.GetValue(VISION_MASK, kStatus);
  printf("obj_num: %d\n", obj_num);
  fflush(stdin);

  if (obj_num) {
    for (int i = 1; i <= obj_num; ++i) {
      int x = sentry.GetValue(VISION_MASK, kXValue, i);
      int y = sentry.GetValue(VISION_MASK, kYValue, i);
      int w = sentry.GetValue(VISION_MASK, kWidthValue, i);
      int h = sentry.GetValue(VISION_MASK, kHeightValue, i);
      int l = sentry.GetValue(VISION_MASK, kLabel, i);
      printf("  obj[%d]: x=%d,y=%d,w=%d,h=%d, label=%s\n", i, x, y, w, h, blob_classes[l]);
      fflush(stdin);
    }
  }
}

int main() {
  printf("start\n");
  setup();
  while (1) {
    loop();
  }
}

