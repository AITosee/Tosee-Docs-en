/**
 * @file main_c_type.c
 * @author donion.yang
 * @brief 用C语言调用Sentry库的示例函数，目前只支持uart方式
 *        
 *        1）
 *        默认提供linux平台的使用方式，使用方法：
 *        确认 CMakeList.txt 中，编译的为 main_c_type.c 函数
 *        add_executable(linux_test main_c_type.c  ${SRC_LIST1} ${SRC_LIST2} ${SRC_LIST3}
 * 
 *        cd test
 *        mkdir build
 *        cd build
 *        cmake ..
 *        make
 *        ./linux_test
 * 
 *        2）
 *        其他平台需要用户修改uart的接口函数
 *        在 “src/hardware/hw_conf.h” 中，关闭 #define _PLATFORM_LINUX_ 的注释，打开 #define _PLATFORM_USER_ 的注释
 *        在 “src/hardware/hw_uart_user.h” 中，填写相关的uart接口函数
 *        使用用户的工具链去编译和运行函数
 *        
 * @version 1.2
 * @date 2023-01-15
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#include "hw_conf.h"
#include "sentry_c_type.h"
#include "stdio.h"
#include "stdint.h"
#include <unistd.h>

#define VISION_MASK kVisionBlob

const char* blob_classes[] = {
  "UNKNOWN", "BLACK", "WHITE", "RED", "GREEN", "BLUE", "YELLOW"
};

void setup() {
  printf("Waiting for sentry initialize...\n");
  /**
   * @brief 初始化sentry硬件
   * 
   */
  #if defined(_PLATFORM_LINUX_)
  sentry_device_begin("/dev/ttyACM0", 115200, 0);
  #elif defined(_PLATFORM_USER_)
  sentry_device_begin(NULL, 115200, 0);
  #endif
  printf("Sentry begin Success.\n");

  /**
   * @brief 设置参数
   *        该功能部分算法可用，如颜色识别，色块检测，人脸识别，学习算法
   *        其他算法无需使用以下这些函数 
   */
  sentry_vision_set_param_number(VISION_MASK, 2); // 设置参数数量为2
  
  sentry_object_c_type_t param = {0};
  param.width = 10;
  param.height = 10;
  param.label = kColorGreen;
  sentry_vision_set_param_value(VISION_MASK, &param, 1); // 将参数设置到第1个参数中
  
  param.width = 5;
  param.height = 5;
  param.label = kColorBlue;
  sentry_vision_set_param_value(VISION_MASK, &param, 2); // 将参数设置到第2个参数中

  /**
   * @brief 开启算法
   * 
   */
  sentry_vision_begin(VISION_MASK);
  printf("sentry.VisionBegin(%d)\n", VISION_MASK);

}

void loop() {
  /**
   * @brief 获取检测结果数量
   * 
   */
  int obj_num = sentry_vision_get_value(VISION_MASK, kStatus, 1);
  printf("obj_num: %d\n", obj_num);
  fflush(stdin);

  /**
   * @brief 如果检测数量>0，则读取结果
   * 
   */
  if (obj_num) {
    for (int i = 1; i <= obj_num; ++i) {
      int x = sentry_vision_get_value(VISION_MASK, kXValue, i); // 读取x坐标
      int y = sentry_vision_get_value(VISION_MASK, kYValue, i); // 读取y坐标
      int w = sentry_vision_get_value(VISION_MASK, kWidthValue, i); // 读取宽度
      int h = sentry_vision_get_value(VISION_MASK, kHeightValue, i); // 读取高度
      int l = sentry_vision_get_value(VISION_MASK, kLabel, i); // 读取标签编号
      printf("  obj[%d]: x=%d,y=%d,w=%d,h=%d, label=%s\n", i, x, y, w, h, blob_classes[l]);
      fflush(stdin);
    }
  }
}

int main() {
  printf("start\n");
  setup();
  while (1) {
    loop();
  }
}

