/**
 * @file hw_uart_linux.h
 * @author donion.yang
 * @brief 用于linux系统下Sentry库的串口调用
 * @version 1.2
 * @date 2023-01-15
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#include "hw_conf.h"
#ifdef _PLATFORM_LINUX_

#include "string.h"
#include "stdio.h"
#include "stdint.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>
#include <fcntl.h>
#include <termios.h>

class Stream {
  public:
  virtual int available(void) = 0;
  virtual size_t readBytes(uint8_t* buf, size_t length) = 0;
  virtual size_t writeBytes(uint8_t* buf, size_t length) = 0;
};

class LinuxUart : public Stream {
  public:
  LinuxUart() {}
  virtual ~LinuxUart() {}
  
  void begin(char* dev, unsigned long baudrate) {
    tty_fd_ = open(dev, O_RDWR|O_NOCTTY|O_NONBLOCK);

    sleep(5); // wait fot sentry startup
    
    if (tty_fd_ < 0) {
      printf("%s open failed:%s\n", dev, strerror(errno));
      goto FAIL;
    }

    memset(&tty_options_, 0, sizeof(tty_options_));

    if (tcgetattr(tty_fd_, &tty_options_) != 0) {
      printf("%s tcgetattr() failed: %s\n", dev, strerror(errno));
      goto FAIL;
    }

    tty_options_.c_cflag |= (CLOCAL|CREAD);
    tty_options_.c_cflag &= ~CSIZE;
    tty_options_.c_cflag |= CS8;      //8位数据
    tty_options_.c_cflag &= ~PARENB;  //无校验位 
    tty_options_.c_cflag &= ~CSTOPB;  //1停止位;
    tty_options_.c_cflag &= ~CRTSCTS; //关闭流控
    tty_options_.c_iflag = 0;
    tty_options_.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG); /*Input Raw Mode*/
    tty_options_.c_oflag &= ~OPOST; /*Input Raw Mode*/
    tty_options_.c_cc[VTIME] = 0; /* 非规范模式读取时的超时时间*/
    tty_options_.c_cc[VMIN]  = 0; /* 非规范模式读取时的最小字符数*/

    switch (baudrate) {
      case 9600:
        baudrate_ = B9600;
        break;
      case 57600:
        baudrate_ = B57600;
        break;
      case 115200:
        baudrate_ = B115200;
        break;
      case 921600:
        baudrate_ = B921600;
        break;
      case 2000000:
        baudrate_ = B2000000;
        break;
      default:
        baudrate_ = B115200;
        printf("%d baudrate not support\n please select: 9600, 57600, 115200, 921600, 2000000\n");
        break;
    }
    cfsetispeed(&tty_options_, baudrate_); 
    cfsetospeed(&tty_options_, baudrate_);
    printf("baudrate set to %d %d\n", baudrate, baudrate_);
    tcflush(tty_fd_ ,TCIOFLUSH);/* tcflush清空终端未完成的输入/输出请求及数据；TCIFLUSH表示清空正收到的数据，且不读取出来 */

    if((tcsetattr(tty_fd_, TCSAFLUSH, &tty_options_))!=0){
      printf("%s tcsetattr failed:%s\n", dev, strerror(errno));
      goto FAIL;
    }

    printf("%s open successful!\n", dev);
    return;

    FAIL:
    printf("%s FAIL\n", dev);
    if (tty_fd_ > 0) {
      close(tty_fd_);
    }
    tty_fd_ = -1;
  }

  void end() {
    if (tty_fd_ > 0) {
      close(tty_fd_);
    }
    tty_fd_ = -1;
  }
  
  int available(void) {
    printf("available not support\n");
    return 0;
  }
  
  size_t readBytes(uint8_t *buffer, size_t length) {
    int rx = 0;
    int left = length;
    uint8_t *pt = buffer;
    size_t tm = timestamp();
    

    while ((left > 0) && (timestamp() - tm < timeout_)) {
      rx = read(tty_fd_, pt, left);
      if (rx > 0) {
        pt += rx;
        left -= rx;
        tm = timestamp();
      }
    }
    usleep(1000);
    return rx;
  }
  
  size_t writeBytes(uint8_t* buffer, size_t length) {
    int tx = 0;
    int left = length;
    uint8_t *pt = buffer;
    size_t tm = timestamp();

    while ((left > 0) && (timestamp() - tm < timeout_)) {
      tx = write(tty_fd_, pt, left);
      
      if (tx > 0) {
        pt += tx;
        left -= tx;
        tm = timestamp();
      }
    }
    usleep(1000);
    return tx;
  }

private:
  int tty_fd_ = -1;
  struct termios tty_options_;
  speed_t baudrate_;
  size_t timeout_ = 500; // ms

  size_t timestamp() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    size_t ms = tv.tv_sec * 1000 + tv.tv_usec / 1000;
    return ms;
  }
};

#endif
