/**
 * @file hw_uart_user.h
 * @author donion.yang
 * @brief 用于其他平台下Sentry库的串口调用
 * @version 1.2
 * @date 2023-01-15
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "hw_conf.h"
#ifdef _PLATFORM_USER_

#include "string.h"
#include "stdio.h"
#include "stdint.h"

class Stream {
  public:
  virtual int available(void) = 0;
  virtual size_t readBytes(uint8_t* buf, size_t length) = 0;
  virtual size_t writeBytes(uint8_t* buf, size_t length) = 0;
};

class UserUart : public Stream {
  public:
  UserUart() {}
  virtual ~UserUart() {}
  
  /**
   * @brief 串口初始化，指定串口设备和波特率
   *        其他默认串口参数：数据为 = 8位，停止位 = 1位，校验 = 无
   * 
   * @param dev 串口设备编号，字符串表示，如果用户只有一个固定的串口设备可用，则可忽略此参数
   * @param baudrate 串口波特率
   */
  void begin(char* dev, unsigned long baudrate) {
    /**
     * @brief 此处填入用户自己的函数
     * 
     */
  }

  /**
   * @brief 关闭串口，释放资源
   * 
   */
  void end() {
    /**
     * @brief 此处填入用户自己的函数
     * 
     */
  }
  
  /**
   * @brief 获取串口缓存中可读取的字节数量
   * 
   * @return int 
   */
  int available(void) {
    size_t len;
    /**
     * @brief 此处填入用户自己的函数，若不用此功能，可忽略
     * 
     */
    return len;
  }
  
  /**
   * @brief 读取数据
   * 
   * @param buffer 将读取的数据放入此缓存中
   * @param length 待读取的字节长度
   * @return size_t 返回实际读取的字节长度
   */
  size_t readBytes(uint8_t *buffer, size_t length) {
    size_t rx;
    /**
     * @brief 此处填入用户自己的函数
     * 
     */
    return rx;
  }
  
  /**
   * @brief 发送数据
   * 
   * @param buffer 将此缓存中的数据发送出去
   * @param length 待发送的字节长度
   * @return size_t 返回实际发送的字节长度
   */
  size_t writeBytes(uint8_t* buffer, size_t length) {
    size_t tx;
    /**
     * @brief 此处填入用户自己的函数
     * 
     */
    return tx;
  }

};

#endif
