/**
 * @file sentry_c_type.cpp
 * @author donion.yang
 * @brief Sentry库的C函数接口
 * @version 1.0
 * @date 2023-01-15
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#include <Sentry.h>
#include "stdio.h"
#include "stdint.h"
#include <unistd.h>
#include "sentry_c_type.h"

typedef Sentry2 Sentry;
static Sentry sentry;

#if defined(_PLATFORM_LINUX_)
  static LinuxUart uart;
#elif defined(_PLATFORM_USER_)
  static UserUart uart;
#endif

int sentry_device_begin(char *uart_dev, int baudrate, int set_default) {
#if defined(_PLATFORM_LINUX_)
  uart.begin(uart_dev, baudrate);
#endif
  return (int)sentry.begin(&uart, set_default);
}

int sentry_vision_begin(int vision_id) {
  return (int)sentry.VisionBegin((tosee_sentry::Sentry2::sentry_vision_e)vision_id);
}

int sentry_vision_end(int vision_id) {
  return (int)sentry.VisionEnd((tosee_sentry::Sentry2::sentry_vision_e)vision_id);
}

int sentry_vision_set_param_number(int vision_id, int max_num) {
  return (int)sentry.SetParamNum((tosee_sentry::Sentry2::sentry_vision_e)vision_id, max_num);
}

int sentry_vision_set_param_value(int vision_id, sentry_object_c_type_t* vision_param, int param_id) {
  return (int)sentry.SetParam((tosee_sentry::Sentry2::sentry_vision_e) vision_id, (tosee_sentry::sentry_object_t*) vision_param, param_id);
}

int sentry_vision_get_value(int vision_id, int vision_obj, int result_id) {
  return (int)sentry.GetValue((tosee_sentry::Sentry2::sentry_vision_e) vision_id, (sentry_obj_info_e)vision_obj, result_id);
}

int sentry_vision_get_status(int vision_id) {
  return (int) sentry.VisionGetStatus((tosee_sentry::Sentry2::sentry_vision_e) vision_id);
}

int sentry_vision_set_default(int vision_id) {
  return (int)sentry.VisionSetDefault((tosee_sentry::Sentry2::sentry_vision_e) vision_id);
}

int sentry_vision_update_result(int vision_id) {
  return (int) sentry.UpdateResult((tosee_sentry::Sentry2::sentry_vision_e) vision_id);
}

