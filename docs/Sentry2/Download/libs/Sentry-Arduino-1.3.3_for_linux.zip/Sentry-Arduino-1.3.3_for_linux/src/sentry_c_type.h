/**
 * @file sentry_c_type.h
 * @author donion.yang
 * @brief Sentry库的C函数接口
 * @version 1.0
 * @date 2023-01-15
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#ifndef SENTRY_C_TYPE_H_
#define SENTRY_C_TYPE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"

enum sentry_vision_c_type_e {
  kVisionColor = 1,
  kVisionBlob = 2,
  kVisionAprilTag = 3,
  kVisionLine = 4,
  kVisionLearning = 5,
  kVisionCard = 6,
  kVisionFace = 7,
  kVision20Classes = 8,
  kVisionQrCode = 9,
  kVisionMotionDetect = 11,
  kVisionMaxType,
};

enum sentry_obj_info_c_type_e {
  kStatus,        //!< whether the target is detected
  kXValue,        //!< target horizontal position
  kYValue,        //!< target vertical position
  kWidthValue,    //!< target width
  kHeightValue,   //!< target height
  kLabel,         //!< target label
  kRValue,        //!< R channel value
  kGValue,        //!< G channel value
  kBValue,        //!< B channel value
} ;

typedef struct {
  union {
    uint16_t result_data1;
    uint16_t x_value;
    uint16_t color_r_value;
    uint16_t top_x_value;
  };
  union {
    uint16_t result_data2;
    uint16_t y_value;
    uint16_t color_g_value;
    uint16_t top_y_value;
  };
  union {
    uint16_t result_data3;
    uint16_t width;
    uint16_t color_b_value;
    uint16_t bot_x_value;
  };
  union {
    uint16_t result_data4;
    uint16_t height;
    uint16_t bot_y_value;
  };
  union {
    uint16_t result_data5;
    uint16_t color;
    uint16_t label;
  };
} sentry_object_c_type_t;

enum color_label_c_type_e {
  kColorBlack = 1,
  kColorWhite = 2,
  kColorRed = 3,
  kColorGreen = 4,
  kColorBlue = 5,
  kColorYellow = 6
};

extern int sentry_device_begin(char *uart_dev, int baudrate, int set_default);
extern int sentry_vision_begin(int vision_id);
extern int sentry_vision_end(int vision_id);
extern int sentry_vision_set_param_number(int vision_id, int max_num);
extern int sentry_vision_set_param_value(int vision_id, sentry_object_c_type_t* vision_param, int param_id);
extern int sentry_vision_get_value(int vision_id, int vision_obj, int result_id);
extern int sentry_vision_get_status(int vision_id);
extern int sentry_vision_set_default(int vision_id);
extern int sentry_vision_update_result(int vision_id);

#ifdef __cplusplus
}
#endif

#endif
