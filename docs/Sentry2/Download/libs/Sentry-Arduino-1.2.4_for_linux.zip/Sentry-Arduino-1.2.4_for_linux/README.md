Sentry SDK for Linux
======

The Sentry is a intelligent sensor module which is easy to use with computer vision applications.

TODO: for more informations...
