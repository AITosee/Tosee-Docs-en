

#include <Sentry.h>
#include "stdio.h"
#include "stdint.h"
#include <unistd.h>

typedef Sentry2 Sentry;

#define SENTRY_UART
#define VISION_MASK Sentry::kVisionColor
Sentry sentry;

LinuxUart linux_uart;

const char* blob_classes[] = {
  "UNKNOWN", "BLACK", "WHITE", "RED", "GREEN", "BLUE", "YELLOW"
};

void setup() {
  sentry_err_t err = SENTRY_OK;
  printf("Waiting for sentry initialize...\n");
  
  linux_uart.begin("/dev/ttyACM0", 921600);

  while (SENTRY_OK != sentry.begin(&linux_uart)) { 
    printf("sentry.begin...\n");
    usleep(200);
  }
  printf("Sentry begin Success.\n");

  err = sentry.VisionBegin(VISION_MASK);
  printf("sentry.VisionBegin(kVisionBlob): %s[0x%x]\n", err ? "Error" : "Success", err);
}

void loop() {
  int obj_num = sentry.GetValue(VISION_MASK, kStatus);
  printf("obj_num: %d\n", obj_num);
  fflush(stdin);

  if (obj_num) {
    for (int i = 1; i <= obj_num; ++i) {
      int x = sentry.GetValue(VISION_MASK, kXValue, i);
      int y = sentry.GetValue(VISION_MASK, kYValue, i);
      int w = sentry.GetValue(VISION_MASK, kWidthValue, i);
      int h = sentry.GetValue(VISION_MASK, kHeightValue, i);
      int l = sentry.GetValue(VISION_MASK, kLabel, i);
      printf("  obj[%d]: x=%d,y=%d,w=%d,h=%d, label=%s\n", i, x, y, w, h, blob_classes[l]);
      fflush(stdin);
    }
  }
}

int main() {
  printf("start\n");
  setup();
  while (1) {
    loop();
  }
}

